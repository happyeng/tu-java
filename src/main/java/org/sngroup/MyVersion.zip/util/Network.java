package org.sngroup.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Network {

    public static void main(String[] args) {
    }

    final public Map<String, Map<String, Set<DevicePort>>> devicePorts; // S A S->A
    final public Map<DevicePort, DevicePort> topology;
    final public Map<String, Map<Integer, VNode>> nodes; // S，0，VNode 用来存放dvnet 存放S0对应的 invariant 和 在dvnet中的边
    int maxNodeIndex;
    Set<String> usedDevices;
    boolean isNodeUsed = false;


    public Network(){
        topology = new Hashtable<>();
        devicePorts = new Hashtable<>();
        nodes = new HashMap<>();
        usedDevices = new HashSet<>();

        maxNodeIndex = 0;
    }

    public Set<String> getUsedDevices(){
        return this.usedDevices;
    }


    public void addTopology(String d1, String p1, String d2, String p2) {
        addDevice(d1);
        addDevice(d2);
        DevicePort dp1 = new DevicePort(d1, p1);
        DevicePort dp2 = new DevicePort(d2, p2);
        topology.put(dp1, dp2);
        topology.put(dp2, dp1);
        devicePorts.get(d1).putIfAbsent(d2, new HashSet<>());
        devicePorts.get(d2).putIfAbsent(d1, new HashSet<>());
        devicePorts.get(d1).get(d2).add(dp1);
        devicePorts.get(d2).get(d1).add(dp2);
    }

    public void addDevice(String name){
        if (nodes.containsKey(name)) return;
        devicePorts.put(name, new HashMap<>());
        nodes.put(name, new HashMap<>());
    }

    public void getDeviceSet(String DVNetFilePath){
        String filePath = DVNetFilePath.replace(".puml", "") + "_nodes.txt";
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String node = scanner.nextLine().trim();
                usedDevices.add(node);
            }

            scanner.close();
            isNodeUsed = true;
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filePath);
            e.printStackTrace();

        }

        System.out.println(usedDevices);
    }

    public void readTopologyByFile(String filepath){

        try {
            InputStreamReader isr = new InputStreamReader(Files.newInputStream(Paths.get(filepath)), StandardCharsets.UTF_8);
            BufferedReader br = new BufferedReader(isr);
            String line;
            String[] token;

            while ((line = br.readLine()) != null) {
                token = line.split("\\s+");

                // add_dfy 只有边的两边都需要时，才加上
                if(isNodeUsed){
                    if(usedDevices.contains(token[0]) && usedDevices.contains(token[2]))
                        addTopology(token[0], token[1], token[2], token[3]);
                }else{
                    addTopology(token[0], token[1], token[2], token[3]);
                }
            }
            isr.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void readDVNet(String DVNetFilePath){
        try {
            BufferedReader br = new BufferedReader(new FileReader(DVNetFilePath));
            String line;
            String packeSpace="";
            String match="";
            String path="";
            Invariant invariant = null;
            int netTag = -1;
            while ((line = br.readLine()) != null){
                if (line.startsWith("'packet_space:")){
                    packeSpace = line.replace("'packet_space:", "").trim();
                    continue;
                }
                if (line.startsWith("'match:")){
                    match = line.replace("'match:", "").trim();
                    continue;
                }
                if (line.startsWith("'path:")){
                    path = line.replace("'path:", "").trim();
                    invariant = new Invariant(packeSpace, match, path);
                    continue;
                }
                if (line.startsWith("@") || line.startsWith("'") || line.startsWith("}")) continue;

                // Pandor: 添加对DVNet的标注
                if (line.startsWith("state")){
                    netTag++;
//                    System.out.println("netTag" + netTag);
                    continue;
                }

                line = line.replaceAll("[()]", "");
                String[] token = line.split("-->|\\.|:");
                int i = 0, n1Index=0, n2Index=0;;
                String d1 = token[i++];
                if (d1.equals("[*]")) i--;
                else n1Index = Integer.parseInt(token[i++]);
                String d2 = token[i++];
                if (d2.equals("[*]"))i--;
                else n2Index = Integer.parseInt(token[i++]);
                VNode node1 = getOrCreateVNode(d1, n1Index, invariant, netTag);
                VNode node2 = getOrCreateVNode(d2, n2Index, invariant, netTag);
                VNode.addLink(node1, node2);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    VNode getOrCreateVNode(String name, int index, Invariant invariant, int netIndex){
        VNode node;
        if(name.equals("[*]")) return new VNode(name, index, invariant, netIndex);
        if(!nodes.get(name).containsKey(index)){
            node = new VNode(name, index, invariant, netIndex);

            // add_dfy
            if(index + 1 > maxNodeIndex){
                maxNodeIndex = index + 1;
            }

            nodes.get(name).put(index, node);
        }else{
            node = nodes.get(name).get(index);
        }
        return node;
    }

}

