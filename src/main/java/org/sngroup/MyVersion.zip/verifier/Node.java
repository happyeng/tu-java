/*
 * This program is free software: you can redistribute it and/or modify it under the terms of
 *  the GNU General Public License as published by the Free Software Foundation, either
 *   version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 *  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 *   PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this
 *  program. If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Chenyang Huang (Xiamen University) <xmuhcy@stu.xmu.edu.cn>
 *          Qiao Xiang     (Xiamen University) <xiangq27@gmail.com>
 *          Ridi Wen       (Xiamen University) <23020211153973@stu.xmu.edu.cn>
 *          Yuxin Wang     (Xiamen University) <yuxxinwang@gmail.com>
 */

package org.sngroup.verifier;

import org.sngroup.Configuration;
import org.sngroup.util.*;

import java.security.Principal;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileWriter;


public class Node {

    public static int numDpvnet = 1;
    public Device device;
    public int index;
    public HashSet<NodePointer> next;
    public HashSet<NodePointer> prev;
    public int netIndex;

    public DVNet dvNet;

    private HashSet<String> nextSet;
    public final String nodeName;
    public TSBDD bdd;
    public boolean hasResult;
    public CibMessage lastResult;

    public Map<NodePointer, Integer> subTable;
    public int totalSub;
    int packetSpace;


    // IPPrefix ipPrefix;

    Invariant invariant;
    String destination;
    String match;
    int match_num;

    private final AtomicInteger waitTask;
    private static final String FILE_PATH = "./result/demoResult.txt";
    private static final Lock fileLock = new ReentrantLock();


    protected HashMap<String, Map<Integer, Announcement>> cibInStore; // 存储收到的CIBIn
    protected Map<NodePointer, Integer> cibInHash;  // 存储上一个CIB

    protected Set<CibTuple> todoList;

    protected Vector<CibTuple> locCib;
    protected Map<ForwardAction, Collection<CibTuple>> actionToCib;
    protected Map<String, List<CibTuple>> portToCib;
    Map<Count, Pair<Integer, Integer>> cibOutMap; // Count, Predicate, ID
    //更新FIB


    //判断是否是最终节点
    protected boolean isIngress = false;
    public boolean isDestination = false;

    int lastSendHashCode = 0;
    int lastSub = 0;

    private final NodePointer nodePointer;

    public String getNodeName() {
        return nodeName;
    }

    public String getDeviceName(){
        return this.device.name;
    }
    public NodePointer getNodePointer() {
        return nodePointer;
    }


    public Node(Device device, int index, Invariant invariant, int netIndex) {
        this.device = device;
        this.index = index;
        this.netIndex = netIndex;
        this.destination = invariant.getPacketSpace();
        // System.out.println(invariant);
        // System.out.println(device.name);
        // System.out.println(invariant.getPacketSpace());

        this.match = invariant.getMatch();
        this.invariant = invariant;

        nodePointer = new NodePointer(device.name, index);
        nodeName = String.format("%s-%s", device.name, index);

        next = new HashSet<>();
        prev = new HashSet<>();
        //------------------------------------------------------------ 2 -------------------------------------------------------------------------//
        hasResult = false;
        cibInStore = new HashMap<>();

        todoList = new HashSet<>();

        subTable = new Hashtable<>();

        cibOutMap = new HashMap<>();

        //merge
        cibInHash = new HashMap<>();
        locCib = new Vector<>();
        actionToCib = new Hashtable<>();

        portToCib = new Hashtable<>();
        waitTask = new AtomicInteger(0);

        lastResult = null;
    }


    public Node(Device device, int index, Invariant invariant) {
        this.device = device;
        this.index = index;
        this.destination = invariant.getPacketSpace();
        // System.out.println(invariant);
        // System.out.println(device.name);
        // System.out.println(invariant.getPacketSpace());

        this.match = invariant.getMatch();
        this.invariant = invariant;

        nodePointer = new NodePointer(device.name, index);
        nodeName = String.format("%s-%s", device.name, index);

        next = new HashSet<>();
        prev = new HashSet<>();
        //------------------------------------------------------------ 2 -------------------------------------------------------------------------//
        hasResult = false;
        cibInStore = new HashMap<>();

        todoList = new HashSet<>();

        subTable = new Hashtable<>();

        cibOutMap = new HashMap<>();

        //merge
        cibInHash = new HashMap<>();
        locCib = new Vector<>();
        actionToCib = new Hashtable<>();

        portToCib = new Hashtable<>();
        waitTask = new AtomicInteger(0);

        lastResult = null;
    }

    int getPacketSpace() {
        return packetSpace;
    }

    // public void acceptSubscribe(Subscriber subscriber) {
    //     if (next.isEmpty()) return;
    //     long s1 = System.nanoTime();
    //     NodePointer src = subscriber.getSrc(); // 哪个节点的订阅
    //     int packetSpaceAdd = subscriber.getNewPacketSpace(); // 订阅的空间
    //     int packetSpaceRem = subscriber.getDeletePacketSpace();
    //     int last = subTable.getOrDefault(src, 0);
    //     int tmp = bdd.ref(bdd.or(last, packetSpaceAdd));
    //     int ps = bdd.ref(bdd.diff(tmp, packetSpaceRem));
    //     bdd.deref(tmp);
    //     bdd.deref(last);
    //     bdd.deref(packetSpaceAdd);
    //     bdd.deref(packetSpaceRem);
    //     subTable.put(src, ps);
    //     if (subTable.size() == prev.size()) {
    //         int res = 0;
    //         for (Integer i : subTable.values()) {
    //             res = bdd.orTo(res, i);
    //         }
    //         totalSub = res;
    //         updateAndSendSubscription();
    //         long s2 = System.nanoTime();
    //     }
    // }
    // public void updateSubscribe(){
    //     updateAndSendSubscription();
    // }

    public void setDvNet(DVNet dvNet){
        this.dvNet = dvNet;
//        bdd = dvNet.getBddEngine().getBDD();
        bdd = dvNet.getBddEngine().getBDD();
    }

    public void setBdd(BDDEngine srcBdd){
        bdd = srcBdd.getBDD();
    }

    private void updateAndSendSubscription(){
        this.packetSpace = device.getSubscribe(totalSub);
        if (!next.isEmpty()) {
            if(getPacketSpace()!=lastSub){
                int increase = bdd.diff(getPacketSpace(), lastSub);
                int decrease = bdd.diff(lastSub, getPacketSpace());
                device.subscribe(index, increase, decrease, next);
                lastSub = getPacketSpace();
            }
        }
    }

    public void startSubscribe(){
        device.subscribe(index, device.totalSpace, 0, next);
    }

    //新函数:收到一个数据包就执行一次，对于其中每个FIB都要做一次
    protected void count(NodePointer from, Context ctx) {
        Event event = Event.getLocalEvent(ctx.getTaskID(), getNodeName(), ctx.getPrevEvent(), 0);
        ctx.setPrevEvent(event);
        long t1 = System.nanoTime(), t2;
        CibMessage message = ctx.getCib();

        // 检查是否是新结果
        boolean isNew = storageAndCheckNew(from, message);
        if (isNew) {
            Collection<Announcement> as = getAnnouncement(from);
            boolean newResult = updateLocCib(from.name, as);
            if (!hasResult) {
                // if(from.name.charAt(0) == 'W'){
                //     System.out.println("1111");
                // }
                t2 = System.nanoTime();
                if (todoList.isEmpty()) {   //第一次计算
                    sendFirstResult(ctx);
                    // if(from.name.charAt(0) == 'W'){
                    //     System.out.println("2222");
                    // }
                }
            } else {
                t2 = System.nanoTime();
                // if(from.name.charAt(0) == 'W'){
                //     System.out.println("333");
                // }
                if (newResult){
                    sendUpdateResult(ctx);
                    // if(from.name.charAt(0) == 'W'){
                    //     System.out.println("444");
                    // }
                }
                    
            }

            // notes_dfy 判断是否是最终节点（现在都没有走到最终节点过
            if (isIngress) {
                if (cibInStore.size() == next.size()) {
                    showResult();
                }
            }
        }else{
            t2 = System.nanoTime();
        }
        event.time = t2 - t1;
    }

    public void addTask() {
        waitTask.incrementAndGet();
    }

    public void finishTask() {
        waitTask.decrementAndGet();
    }

    public boolean storageAndCheckNew(NodePointer from, CibMessage message) {
        Integer lastMessageHash = cibInHash.get(from);
        int newHash = message.hashCode();
        if (lastMessageHash != null && lastMessageHash == newHash) return false;
        cibInHash.put(from, newHash);
        cibInStore.putIfAbsent(from.name, new Hashtable<>());
        Map<Integer, Announcement> table = cibInStore.get(from.name);
        for (Announcement a: message.announcements){
            table.put(a.id, a);
        }
        for (Integer id: message.withdraw){
            table.remove(id);
        }
        return true;
    }

    public Collection<Announcement> getAnnouncement(NodePointer from) {
        return cibInStore.get(from.name).values();
    }


    // 只在结果未计算出前计算
    public boolean updateLocCib(String from, Collection<Announcement> announcements) {
        // if(from.charAt(0) == 'W'){
        //     System.out.println("0000");
        // }

        boolean newResult = false;
        Queue<CibTuple> queue = new LinkedList<>(portToCib.get(from));
        while (!queue.isEmpty()){

            CibTuple cibTuple = queue.poll();
            for(Announcement announcement: announcements){
                int intersection = bdd.ref(bdd.and(announcement.predicate, cibTuple.predicate));
                
                // add_dfy
                // int intersection = bdd.and(announcement.predicate, cibTuple.predicate);
                
                if (intersection == BDDEngine.BDDFalse) continue;
                if (intersection != cibTuple.predicate){
                    CibTuple newCibTuple = cibTuple.keepAndSplit(intersection, bdd); // 拆分CIBTuple
                    addCib(newCibTuple);
                    if(!hasResult && todoList.contains(cibTuple))
                        todoList.add(newCibTuple);
                    queue.add(newCibTuple);
                }
                newResult |= cibTuple.set(from, new Count(announcement.count));
                if(cibTuple.isDefinite()) {
                    if (!hasResult) {
                        todoList.remove(cibTuple);
                    }
                    break;
                }
            }
        }
        return newResult;
    }

    public void recompute(Context context) {
        initializeCib();
        for (Map.Entry<String, Map<Integer, Announcement>> entry:cibInStore.entrySet()) {
            updateLocCib(entry.getKey(), entry.getValue().values());
        }
        sendUpdateResult(context);
    }

    protected void addCib(CibTuple cib){
        locCib.add(cib);
        updateActionPortTable(cib);
    }

    private void updateActionPortTable(CibTuple cib){
        // if(device.name.charAt(0) == 'W'){
        //     System.out.println("555");
        // }
        // cib的关键属性: action port
        actionToCib.putIfAbsent(cib.action, new Vector<>());
        actionToCib.get(cib.action).add(cib);
        for(String port: cib.action.ports) {
            portToCib.putIfAbsent(port, new Vector<>());
            portToCib.get(port).add(cib);
        }
    }

    protected void moveCibAction(CibTuple cib, ForwardAction newAction){
        actionToCib.get(cib.action).remove(cib);
        for(String port: cib.action.ports) {
            portToCib.get(port).remove(cib);
        }
        cib.action = newAction;
        cib.clear();

        recomputedCibCausality(cib);
        updateActionPortTable(cib);
        cib.recompute();
    }

    protected void recomputedCibCausality(CibTuple cib){
        cib.factorNumber = 0;
        for (String next: cib.action.ports){
            if (!nextSet.contains(next)) continue;
            cib.factorNumber += 1;
            Collection<Announcement> announcements = cibInStore.get(next).values();
            for(Announcement announcement: announcements){
                if (bdd.and(announcement.predicate, cib.predicate) != 0){
                    cib.set(next, new Count(announcement.count));
                    break;
                }
            }
        }
        cib.recompute();
    }


    //------------------------------- change: predicate from port A to port B ---------------------------------

    //把下游为oldPort 或 newPort的CIB全部删除，再把下游为oldPort 或 newPort的LEC全部重新计算 drop项单独处理

    public void updateByChange(List<Change> changeList, Context ctx) {
        if (changeList.size() == 0 || isDestination || isIngress) {
            return;
        }
        Event e = Event.getLocalEvent(ctx.getTaskID(), getNodeName(), ctx.getPrevEvent(), 0);
        ctx.setPrevEvent(e);
        long t1 = System.nanoTime(), t2;
        boolean changeFlag = false;
        for (Change change: changeList) {
            boolean oldCorrelation = change.getOldAction().isCorrelation(nextSet), newCorrelation = change.getNewAction().isCorrelation(nextSet);
            ForwardAction newAction = newCorrelation?change.getNewAction():ForwardAction.getNullAction();
            int pre = change.getHit();
            // 与下游节点相关时才进行变动。
            if ( oldCorrelation || newCorrelation){
                Collection<CibTuple> oldCibs = actionToCib.get(change.getOldAction());
                if (oldCibs == null) oldCibs = new Vector<>();
                oldCibs.addAll(actionToCib.get(ForwardAction.getNullAction()));
                oldCibs = new Vector<>(oldCibs); // 删掉后会产生未知BUG
                for (CibTuple cib: oldCibs){
                    int intersection = bdd.and(pre, cib.predicate);
                    if (intersection != 0) {
                        if(intersection != cib.predicate){
                            CibTuple newcib = cib.keepAndSplit(intersection, bdd);
                            addCib(newcib);
                        }
                        moveCibAction(cib, newAction);
                    }
                }

                changeFlag = true;
            }
        }
        t2 = System.nanoTime();
        if (changeFlag) sendUpdateResult(ctx);
        e.time = t2-t1;
    }


    // 根据LEC和该节点的下一跳初始化LocCIB表
    public void initializeCib() {
        for (String name: nextSet){
            portToCib.put(name, new Vector<>());
        }
//        System.out.println("读取CIBnetIndex" + netIndex);
        int usedSpace = 0;
        // 如果是最终节点， 则直接设置结果为1
        if(isDestination){
            usedSpace = getPacketSpace();
            CibTuple _cibTuple = new CibTuple(getPacketSpace(), ForwardAction.getNullAction(), 0);
            _cibTuple.count.set(1);
            addCib(_cibTuple);
        }

        // 根据lec初始化
//        System.out.println("device" + this.device.name + "  在图  " + netIndex + "初始化CIB" );
//        for(Map.Entry<Integer, List<Lec>> entry : device.lecsByNet.entrySet()){
//            System.out.println("device" + this.device.name + "  所有的LEC" + entry.getKey());
//        }


//        System.out.println("最后读取的NETINDEX  " + netIndex);
//        for (Lec lec : device.lecsByNet.get(netIndex)) {
//            System.out.println("device  " + this.device.name + "在net  " + netIndex + "处的LECS表项  " + lec.predicate);
//        }
//                    try {
//                Thread.sleep(2000);
//            } catch (InterruptedException e) {
//                Thread.currentThread().interrupt();
//                return;
//            }

//        for (Lec lec : device.lecsByNet.get(netIndex)) {
        int a = 1;
//        System.out.println("deviceName" + device.name);
        for (Lec lec : dvNet.getDeviceLecs(device.name)) {
//        for (Lec lec : device.lecs) {
//            System.out.println("移除sCNt" + a++);
            HashSet<String> f = new HashSet<>(nextSet);
            for (String s : nextSet) {
                if (!lec.forwardAction.ports.contains(s)) {
                    f.remove(s);
                }
            }
            // 只计算与下一跳有关的LEC
            if(!f.isEmpty()) {
                int intersection = bdd.and(lec.predicate, getPacketSpace());
//                System.out.println("predicate" + lec.predicate + "packetSpace" + getPacketSpace() + "intersection" + intersection);
                if(intersection != 0) {
                    CibTuple cibTuple = new CibTuple(intersection, lec.forwardAction, f.size());
                    usedSpace = bdd.orTo(usedSpace, intersection);
                    addCib(cibTuple);
                    todoList.add(cibTuple);
                }
            }

        }

        // 需要把任务内的所有包空间用完，将没用完的部分结果设置为0
        if(usedSpace != getPacketSpace()){
            int tmp = bdd.ref(bdd.diff(getPacketSpace(), usedSpace));
            CibTuple cibTuple = new CibTuple(tmp, ForwardAction.getNullAction(), 0);
            addCib(cibTuple);
        }
    }


    //FIB-->初始化CIB-->初始化cibHis-->收到数据包，第一次计数：计算cibHis-->更新CIB 得到CIBOut
    public void start() {
        // System.out.println(destination);
        // System.out.println(device.deviceSpace);
        // System.out.println(device.name);
//        packetSpace = device.deviceSpace.get(destination);
        packetSpace = dvNet.packetSpace;
        // System.out.println(device.name);

        // 因为是DVNET是DFA，下一跳的设备是唯一的，所以只保留名字，舍去序号。
        nextSet = new HashSet<>();
        for (NodePointer n : next) {
            nextSet.add(n.name);
        }

//        checkNextDpvnet();

        initializeCib();
        

        if (prev.size() == 0) {
            isIngress = true;
            match_num = Integer.parseInt(match.split("\\s+")[2]);
//            isEnd = true;
        }
        
    }

    //FIB-->初始化CIB-->初始化cibHis-->收到数据包，第一次计数：计算cibHis-->更新CIB 得到CIBOut
    public void dvNetStart() {
        packetSpace = dvNet.packetSpace;
        // 因为是DVNET是DFA，下一跳的设备是唯一的，所以只保留名字，舍去序号。
        nextSet = new HashSet<>();
        for (NodePointer n : next) {
            nextSet.add(n.name);
        }
        initializeCib();
        if (prev.size() == 0) {
            isIngress = true;
            match_num = Integer.parseInt(match.split("\\s+")[2]);
        }
    }

    // 从LocCIB中导出CIBOut
    public Map<Count, Integer> getCibOut() {
        Map<Count, Integer> cibOut = new HashMap<>();

        for (CibTuple cibTuple : locCib) {
            if (cibTuple.predicate == 0) continue;
            if(cibOut.containsKey(cibTuple.count)){
                int pre = cibOut.get(cibTuple.count);
                pre = bdd.orTo(pre, cibTuple.predicate);
                cibOut.put(cibTuple.count, pre);
            }else{
                cibOut.put(cibTuple.count, cibTuple.predicate);
            }
        }
        return cibOut;
    }
    public void sendUpdateResult(Context ctx){
        long t1 = System.nanoTime(), t2;
        Event e = Event.getSendEvent(ctx.getTaskID(), getNodeName(), ctx.getPrevEvent(), 0);

        List<Announcement> announcements = new LinkedList<>();
        List<Integer> withdrawn = new LinkedList<>();

        Map<Count, Integer> cibOut = getCibOut();

        for(Map.Entry<Count, Integer> entry: cibOut.entrySet()){
            Count newCount = entry.getKey();
            int newPredicate = entry.getValue();
            if (cibOutMap.containsKey(newCount)){
                Pair<Integer, Integer> pair = cibOutMap.get(newCount);
                int oldPredicate = pair.getFirst();
                int oldId = pair.getSecond();
                if(newPredicate == oldPredicate) continue;
                withdrawn.add(oldId);
            }
            int id = cibOutMap.size();
            cibOutMap.put(newCount, new Pair<>(newPredicate, id));
            announcements.add(new Announcement(id, newPredicate, newCount.count));
        }

        CibMessage cibMessage = new CibMessage(announcements, withdrawn, index);
        ctx.setPrevEvent(e);
        ctx.setCib(cibMessage);

        sendCount(ctx);
        t2 = System.nanoTime();
        e.time = t2-t1;

    }

    public void sendFirstResult(Context ctx){
        if(todoList.isEmpty() && !hasResult && !prev.isEmpty()) {
            long t1 = System.nanoTime(), t2;
            Event e = Event.getSendEvent(ctx.getTaskID(), getNodeName(), ctx.getPrevEvent(), 0);
            ctx.setPrevEvent(e);

            List<Announcement> announcements = new LinkedList<>();

            Map<Count, Integer> cibOut = getCibOut();

            for(Map.Entry<Count, Integer> entry: cibOut.entrySet()){
                int id = cibOutMap.size();
                cibOutMap.put(entry.getKey(), new Pair<>(entry.getValue(), id));
                announcements.add(new Announcement(id, entry.getValue(), entry.getKey().count));
            }

            CibMessage cibMessage = new CibMessage(announcements, new LinkedList<>(), index);
            ctx.setCib(cibMessage);

            sendCount(ctx);
            hasResult = true;
            t2 = System.nanoTime();
            e.time = t2-t1;
        }
    }

    //--------------------------------------------------------- 接收+发送------------------------------------------------------
    public void startCount(Context c) {
        long s = System.nanoTime(), e;
        Event localEvent = Event.getLocalEvent(c.getTaskID(), getNodeName(), c.getPrevEvent(), 0);
        c.setPrevEvent(localEvent);
        if (this.isDestination) {
            Announcement a = new Announcement(0, getPacketSpace(), Utility.getOneNumVector(1));
            Vector<Announcement> al = new Vector<>();
            al.add(a);

            CibMessage cibOut = new CibMessage(al, new ArrayList<>(), index);
            c.setCib(cibOut);
            e = System.nanoTime();
            sendCount(c);
            lastResult = cibOut;
            hasResult = true;
        }else if(todoList.isEmpty()){
            e = System.nanoTime();
            sendFirstResult(c);
        }else{
            return;
        }
        localEvent.time = e-s;
    }

    public void sendCount(Context ctx) {

        int hashCode = ctx.getCib().hashCode();
        if(hashCode == lastSendHashCode) {
            return;
        }

        lastResult = ctx.getCib();
//        inverseTransform(ctx.getCib());
//        device.sendCount(ctx, index);
//        if (Configuration.getConfiguration().isUseOneThreadOneDpvnet()) {
//            device.sendDstCount(ctx, index, isDestination);
//        }else{
            device.sendCount(ctx, index);
//        }

        lastSendHashCode = ctx.getCib().hashCode();
    }

    public void inverseTransform(CibMessage message){
        Vector<Announcement> announcements = message.announcements;
        for(Announcement announcement: announcements){
            announcement.predicate = device.inverseTransform(announcement.predicate);
        }
    }

    public void addNext(NodePointer n) {
        next.add(n);
    }

    public void addPrev(NodePointer n) {
        prev.add(n);
    }

    public void receiveCount(Context ctx, NodePointer np){
//        addTask();
        count(np, ctx);
//        finishTask();
    }


    public void close () {
//            th.interrupt();
    }

    @Override
    public String toString() {
        return getNodeName();
    }


    public synchronized void showResult() {
        if (Configuration.getConfiguration().isShowResult()) {
            Map<Count, Integer> cibOut = getCibOut();
            CibMessage cibMessage = new CibMessage();

            final boolean[] success = {true};

            for (Map.Entry<Count, Integer> entry : cibOut.entrySet()) {
                entry.getKey().count.forEach(i -> success[0] &=i>=match_num);
                cibMessage.announcements.add(new Announcement(cibMessage.announcements.size(), entry.getValue(), entry.getKey().count));
            }
            // System.out.println(match);
            // System.out.println(invariant);
            System.out.println("invariants: (" + match + ", "+ invariant.getPath() + ", packet space:" + packetSpace + ") , result: "+success[0]);

            try {
                // 加锁
                
                fileLock.lock();
                // 打开文件并追加写入
                BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true));

                // 写入线程名和一些内容
                writer.write("invariants: (" + match + ", "+ invariant.getPath() + ", packet space:" + packetSpace + ") , result: "+success[0] + "\n");

                // 关闭写入流
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                // 释放锁
                fileLock.unlock();
            }

            System.out.println("Num of DPVnets been verified: " + numDpvnet++);

            lastResult = cibMessage;
            hasResult = true;

            
//            for(String dst: device.spaceMap.keySet()){
//                if(dst.equals(device.name)) continue;
//                System.out.println("detail result: " + device.name + " to " + dst + " ");
//                int space = device.spaceMap.get(dst);
//                int total = 0;
//                for(Map.Entry<Count, Integer> entry: cibOut.entrySet()){
//                    int _pre = bdd.ref(bdd.and(entry.getValue(), space));
//                    if(_pre == 0) continue;
////                if(entry.getKey().isNotZero())
//                    {
//                        System.out.print(entry.getKey() + " ");
//                        device.bddEngine.printSet(_pre);
//                        System.out.println();
////                    bdd.print(_pre);
//                    }
//                    total = bdd.orTo(total, _pre);
//                }
//                if(total != space){
//                    System.out.println("The results are incomplete!");
//                }
//            }
//            StringBuilder result = new StringBuilder();
//            result.append(device.name).append("->").append(destination).append(" result:").append(" ");
//            for(Announcement a: lastResult.announcements){
//                result.append("(").append(a.countToString()).append(", {").append(device.bddEngine.getSet(a.predicate)).append("}) ");
//            }
//            System.out.println(result);

        }
    }

    // 判断对应packet space 的 下一跳是否在dpvnet中
    synchronized public void checkNextDpvnet(){
        // if(device.getCheckMap(packetSpace)){ // 这个packetspace

        // }
        for (Lec lec : device.lecs) {
            int intersection = bdd.and(lec.predicate, getPacketSpace());
            if(intersection != 0) {
                for(String tp: lec.forwardAction.ports){
                    // 表示 这个 lec 不在 nextset 中
                    if(!nextSet.contains(tp)){
                        showFalseResult_checkMiddle(lec);
                        
                    }
                }
                
            }
            

        }
    }

    public synchronized void showFalseResult_checkMiddle(Lec lec) {
        if (Configuration.getConfiguration().isShowMiddleResult()) {
            Map<Count, Integer> cibOut = getCibOut();
            CibMessage cibMessage = new CibMessage();

            final boolean[] success = {true};

            for (Map.Entry<Count, Integer> entry : cibOut.entrySet()) {
                entry.getKey().count.forEach(i -> success[0] &=i>=match_num);
                cibMessage.announcements.add(new Announcement(cibMessage.announcements.size(), entry.getValue(), entry.getKey().count));
            }
            // System.out.println(match);
            // System.out.println(invariant);
            // String ps = device.bddEngine.printSet(packetSpace);
            // String lecs = String.format("{%s, %s}", lec.forwardAction, device.bddEngine.printSet(lec.predicate));
            System.out.println("invariants: (" + match + ", "+ invariant.getPath() + ", packet space:" + packetSpace + ") , result: !! Incorrect Path in " + device.name + index + " of " + lec.toString());
        }
    }

}
