package org.sngroup.verifier;

import jdd.bdd.BDD;
import jdd.util.Array;
import org.sngroup.test.runner.ThreadRunner;
import org.sngroup.util.Network;
import org.sngroup.test.runner.Runner;
import org.sngroup.util.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
public class DVNet {
    public int netIndex;

    private Set<Device> devices;

    private List<Node> nodes;


    private BDDEngine bddEngine;

    private Node dstNode;

    private List<Node> srcNodes;

    public int packetSpace;

    public Map<String, Trie> trieTable;


    // 先分开管理, 验证并行度, 之后再行合并
    // device rule hit
    public Map<String, Map<Rule, Integer>> deviceRuleHit;
    public Map<String, Map<Rule, Integer>> deviceRuleMatch;
    public Map<String, Map<Rule, Integer>> deviceRuleLecIndex;
    public Map<String, Map<ForwardAction, Integer>> devicePortPredicate;
    public Map<String, Map<ForwardAction, Integer>> devicePortIndex;
    public Map<String, List<Lec>> deviceLecs;


    public void putDeviceIfAbsent(String name){
        if(!deviceRuleHit.containsKey(name)){
            this.deviceRuleHit.put(name, new HashMap<>());
            this.deviceRuleMatch.put(name, new HashMap<>());
            this.deviceRuleLecIndex.put(name, new HashMap<>());
            this.devicePortPredicate.put(name, new HashMap<>());
            this.devicePortIndex.put(name, new HashMap<>());
            this.deviceLecs.put(name, new ArrayList<>());
        }
        else return;
    }

    // put Attribute
    // get Attribute
    public void putDeviceRuleHit(String deviceName, Rule rule, int hit){
//        if(!deviceRuleHit.get(deviceName).containsKey(rule))
            deviceRuleHit.get(deviceName).put(rule, hit);
    }

    public void putDeviceRuleMatch(String deviceName, Rule rule, int match){
//        if(!deviceRuleMatch.get(deviceName).containsKey(rule))
            deviceRuleMatch.get(deviceName).put(rule, match);
    }
    public void putDeviceRuleLecIndex(String deviceName, Rule rule, int lecIndex){
//        if(!deviceRuleLecIndex.get(deviceName).containsKey(rule))
            deviceRuleLecIndex.get(deviceName).put(rule, lecIndex);
    }
    public void putDevicePortPredicate(String deviceName, ForwardAction forwardAction, int predicate){
//        if(!devicePortPredicate.get(deviceName).containsKey(forwardAction))
            devicePortPredicate.get(deviceName).put(forwardAction, predicate);
    }
    public void putDevicePortIndex(String deviceName,  ForwardAction forwardAction, int index){
//        if(!devicePortIndex.get(deviceName).containsKey(forwardAction))
            devicePortIndex.get(deviceName).put(forwardAction, index);
    }

    // get Attribute
    public int getDeviceRuleHit(String deviceName, Rule rule){
        return this.deviceRuleHit.get(deviceName).get(rule);
    }

    public int getDeviceRuleMatch(String deviceName, Rule rule){
        return this.deviceRuleMatch.get(deviceName).get(rule);
    }
    public int getDeviceRuleLecIndex(String deviceName, Rule rule){
        return this.deviceRuleLecIndex.get(deviceName).get(rule);
    }
    public int getDevicePortPredicate(String deviceName, ForwardAction forwardAction){
        return this.devicePortPredicate.get(deviceName).get(forwardAction);
    }
    public int getDevicePortIndex(String deviceName,  ForwardAction forwardAction){
        return this.devicePortIndex.get(deviceName).get(forwardAction);
    }
    public List<Lec> getDeviceLecs(String deviceName){
        return this.deviceLecs.get(deviceName);
    }

    public String getDstDeviceName(){return this.dstNode.device.name;}




    public  synchronized void  dvNetParseSpace(Map<String, List<IPPrefix>> spaces){
        // 只需要拿到dvnet中目的device的packet Space 即可
        BDDEngine bddEngine = this.getBddEngine();
        Node dstNode = this.getDstNode();
        String dstDevice = dstNode.getDeviceName();
        List<IPPrefix> ipPrefixList = spaces.get(dstDevice);
        int s = bddEngine.encodeDstIPPrefixList(ipPrefixList);
//        System.out.println("目的结点转化S  " + s);
        this.setPacketSpace(s);
//        spaces.clear();
//        long t1 = System.nanoTime();
//        deviceSpace = new HashMap<>();
//        Node dstNode = dvNet.getDstNode();
//        String dstDevice = dstNode.getDeviceName();
//        for(Map.Entry<String, List<IPPrefix>> entry: spaces.entrySet()){
//            String device = entry.getKey();
//            List<IPPrefix> ipPrefixList = entry.getValue();
//            // add_dfy 只设置第一个packet space
//             int s = bddEngine.encodeDstIPPrefixList(entry.getValue());
//            deviceSpace.put(device, s);
//            if(device == dstDevice) dvNet.setPacketSpace(s);
//        }
//        long t2 = System.nanoTime();
//        buildSpaceTime = t2-t1;
//        spaces.clear();
    }



    public DVNet(int netIndex){
        init();
        this.bddEngine = new BDDEngine();
        this.netIndex = netIndex;
    }

    public DVNet(int netIndex, BDDEngine srcBdd){
        init();
        this.bddEngine = srcBdd;
        this.netIndex = netIndex;
    }


    public void copyBdd(BDDEngine srcBdd){
        this.bddEngine = (BDDEngine) srcBdd.clone();
//        this.bddEngine = srcBdd;
        for(Node node : nodes){
            node.setBdd(this.bddEngine);
        }
    }

    public void copyLecs(Map<String, List<Lec>> srcLecs){
        // 拷贝lec
        Map<String, List<Lec>> deepCopy = new HashMap<>();
        for (Map.Entry<String, List<Lec>> entry : srcLecs.entrySet()) {
            List<Lec> listCopy = new ArrayList<>();
            for (Lec lec : entry.getValue()) {
                listCopy.add(new Lec(lec));
            }
            deepCopy.put(entry.getKey(), listCopy);
        }
        this.deviceLecs = deepCopy;
        // 共用lec
//        this.deviceLecs = srcLecs;
    }

    public BDDEngine getBddEngine(){
        return this.bddEngine;
    }

    public Set<Device> getDevices(){
        return this.devices;
    }

    public boolean addDevice(Device device){
        if(devices.contains(device)) return false;
        else this.devices.add(device);
        return true;
    }

    public void setPacketSpace(int s) {this.packetSpace = s;}

    public void setDstNode(Node node){
        this.dstNode = node;
    }

    public void addNode(Node node){ this.nodes.add(node);}

    public void addSrcNode(Node node){
        this.srcNodes.add(node);
    }

    public Node getDstNode() {return this.dstNode;}

    public List<Node> getNodes(){return this.nodes;}

    public int getPacketSpace(){return this.packetSpace;}

    public void initNode(){
        for(Node node:nodes){
            node.dvNetStart();
        }
    }

    public void startCount(Event event){
//        System.out.println("DvNET  " + netIndex + "  终点开始计数");
        Context c = new Context();
        c.setTaskID(event.id);
        c.setPrevEvent(event);
        this.dstNode.startCount(c);
    }

    public void init(){
        this.devices = new HashSet<>();
        this.srcNodes = new ArrayList<>();
        this.nodes = new ArrayList<>();
        this.deviceRuleHit = new HashMap<>();
        this.deviceRuleMatch = new HashMap<>();
        this.deviceRuleLecIndex = new HashMap<>();
        this.devicePortPredicate = new HashMap<>();
        this.devicePortIndex = new HashMap<>();
//        this.deviceLecs = new HashMap<>();
        this.trieTable = new HashMap<>();
    }



}
