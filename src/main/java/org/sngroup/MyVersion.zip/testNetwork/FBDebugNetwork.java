// package common.network;

// import common.*;
// import common.util.Recorder;

// import java.io.*;
// import java.util.LinkedList;
// import java.util.List;
// import java.util.logging.Level;
// import java.util.logging.Logger;

// public class FBDebugNetwork  extends FattreeDebugNetwork{
//    int edgeSwitchNumber;


//    public FBDebugNetwork(int npod) {
//        super(npod);
//        onlySource = false;
//        edgeSwitchNumber = npod * 48;
//    }

//    private static FBDebugNetwork buildTopology(int npod) {
//        FBDebugNetwork n = new FBDebugNetwork(npod);

//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iFsw = 0; iFsw < 4; iFsw++) {
//                String fsw = "fsw-" + iPod + "-" + iFsw;
//                // down links
//                for (int iRsw = 0; iRsw < 48; iRsw++) {
//                    String rsw = "rsw-" + iPod + "-" + iRsw;
//                    n.addTopology(fsw, fsw + ">" + rsw, rsw, rsw + ">" + fsw);
//                }
//                // up links
//                for (int iSsw = 0; iSsw < 48; iSsw++) {
//                    String ssw = "ssw-" + iFsw + "-" + iSsw;
//                    n.addTopology(fsw, fsw + ">" + ssw, ssw, ssw + ">" + fsw);
//                }
//            }
//        }
//        return n;
//    }


//    public void addEdgeSwitch(){
//        addEdgeSwitch(true);
//    }


//    public void addEdgeSwitch(boolean addInitTime){
//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iRsw = 0; iRsw < 48; iRsw++) {
// //                if(selectEdge && edgeIndex!=iRsw) continue;
//                String rsw = "rsw-" + iPod + "-" + iRsw;
//                Device device = new Device(rsw, this);
//                List<Rule> rules = new LinkedList<>();
//                deviceMap.put(rsw, device);
//                for (int jPod = 0; jPod < npod; jPod++) {
//                    for (int jRsw = 0; jRsw < 48; jRsw++) {
//                        String dstrsw = "rsw-" + jPod + "-" + jRsw;
//                        long dstip = ((long) jPod << 24) + ((jRsw + 1) << 16);
//                        if (dstrsw.equals(rsw)) {
//                            rules.add(new Rule(dstip, 16, rsw + ">h-" + jPod + "-" + jRsw));
//                        } else {
//                            String dstfsw = "fsw-" + iPod + "-" + (48 * jPod + jRsw) % 4;
//                            rules.add(new Rule(dstip, 16, rsw + ">" + dstfsw));
//                        }
//                    }
//                }
//                device.readRules(rules);
//            }
//        }
//    }

//    public void addEdgeNode(int index, Device device, int iPod, int rsw){
//        List<NodePointer> next = new LinkedList<>();
//        List<NodePointer> prev = new LinkedList<>();
//        int i = iPod*48+rsw;
//        for (int jRsw = 0; jRsw < 4; jRsw++) {
//            String dstfsw = "fsw-" + iPod + "-" + jRsw;
//            if (i == index) {
//                next.add(new NodePointer(device.name + ">" + dstfsw, index));
//            }else{
//                prev.add(new NodePointer(device.name + ">" + dstfsw, index));
//            }
//        }
//        device.addNode(index, prev, next);
//    }

//    public void addEdgeNode(int index){
//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iRsw = 0; iRsw < 48; iRsw++) {
//                String rsw = "rsw-" + iPod + "-" + iRsw;
//                Device device = deviceMap.get(rsw);
//                addEdgeNode(index, device, iPod, iRsw);
//            }
//        }
//    }

//    public void addAggregationSwitch(){
//        for (int iPod = 0; iPod < npod; iPod++){
//            for (int iSpine = 0; iSpine < 4; iSpine++) {
//                if(selectAggregation && iSpine!=aggregationIndex) continue;
//                String fsw = "fsw-" + iPod + "-" + iSpine;
//                Device device = new Device(fsw, this);
//                deviceMap.put(fsw, device);
//                List<Rule> rules = new LinkedList<>();
//                for (int jPod = 0; jPod < npod; jPod++) {
//                    for (int jRsw = 0; jRsw < 48; jRsw++) {
//                        String dstrsw = "rsw-" + jPod + "-" + jRsw;
//                        long dstip = ((long) jPod << 24) + ((long) (jRsw + 1) << 16);
//                        Rule rule;
//                        if (jPod == iPod) { // intra pod
//                            rule = new Rule(dstip, 16, fsw + ">" + dstrsw);
//                        } else {
//                            String dstssw = "ssw-" + iSpine + "-" + (48 * jPod + jRsw) % 48;
//                            rule = new Rule(dstip, 16, fsw + ">" + dstssw);
//                        }
//                        rules.add(rule);
//                    }
//                }
//                device.readRules(rules);

//            }
//        }
//    }

//    public void addAggregationNode(int index, Device device, int iPod, int fsw){
//        List<NodePointer> next = new LinkedList<>();
//        List<NodePointer> prev = new LinkedList<>();
//        int jPod = index / 48;
//        int jRsw = index - jPod * 48;

//        if (jPod == iPod) { // intra pod
//            prev.add(new NodePointer(device.name + ">" + "rsw-" + iPod + "-" + jRsw, index));
//            for (int kRsw = 0; kRsw < 48; kRsw++) {
//                if (kRsw == jRsw) continue;
//                next.add(new NodePointer(device.name + ">" + "rsw-" + iPod + "-" + kRsw, index));
//            }
//            for (int iSsw = 0; iSsw < 48; iSsw++) {
//                next.add(new NodePointer(device.name + ">" + "ssw-" + fsw + "-" + iSsw, index));
//            }
//        } else {
//            for (int kRsw = 0; kRsw < 48; kRsw++) {
//                next.add(new NodePointer(device.name + ">" + "rsw-" + iPod + "-" + kRsw, index));
//            }
//            for (int iSsw = 0; iSsw < 48; iSsw++) {
//                prev.add(new NodePointer(device.name + ">" + "ssw-" + fsw + "-" + iSsw, index));
//            }
//        }
//        device.addNode(index, prev, next);
// //        System.out.println(device.name + " " + index + " " + prev + " " + next);
//    }

//    public void addAggregationNode(int index){
//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iFsw = 0; iFsw < 4; iFsw++) {
//                String fsw = "fsw-" + iPod + "-" + iFsw;
//                Device device = deviceMap.get(fsw);
//                if(device != null)
//                    addAggregationNode(index, device, iPod, iFsw);
//            }
//        }
//    }

//    public void addCoreSwitch(){
//        for (int iSpine = 0; iSpine < 4; iSpine++) { // spine id
//            if(selectCore && iSpine!=coreIndex) continue;
//            for (int iSsw = 0; iSsw < 48; iSsw++) {
// //                if(selectCore && iSpine!=coreIndex) continue;
//                String ssw = "ssw-" + iSpine + "-" + iSsw;
//                Device device = new Device(ssw, this);
//                deviceMap.put(ssw, device);
//                List<Rule> rules = new LinkedList<>();
//                for (int k = 0; k < npod; k++) {
//                    for (int l = 0; l < 48; l++) {
//                        long dstip = ((long) k << 24) + ((l + 1) << 16);
//                        String dstfsw = "fsw-" + k + "-" + iSpine;
//                        rules.add(new Rule(dstip, 16, ssw + ">" + dstfsw));
//                    }
//                }
//                device.readRules(rules);
//            }
//        }
//    }

//    public void addCoreNode(int index, Device device, int iSpine, int iSsw) {
//        List<NodePointer> next = new LinkedList<>();
//        List<NodePointer> prev = new LinkedList<>();
//        int k = index / 48;
//        for (int jPod = 0; jPod < npod; jPod++) {
//            if (jPod == k) {
//                prev.add(new NodePointer(device.name + ">" + "fsw-" + k + "-" + iSpine, index));
//            } else {
//                next.add(new NodePointer(device.name + ">" + "fsw-" + jPod + "-" + iSpine, index));
//            }
//        }
//        device.addNode(index, prev, next);
//    }

//    public void addCoreNode(int index){
//        for (int iSpine = 0; iSpine < 4; iSpine++) {
//            for (int iSsw = 0; iSsw < 48; iSsw++) {
//                String ssw = "ssw-" + iSpine + "-" + iSsw;
//                Device device = deviceMap.get(ssw);
//                if(device != null)
//                    addCoreNode(index, device, iSpine, iSsw);
//            }
//        }
//    }

//    public void addNode(int index){
//        addCoreNode(index);
//        addAggregationNode(index);
//        addEdgeNode(index);
//    }

// //    public void run(){
// //        aggregationMessageQueue.clear();
// //        coreMessageQueue.clear();
// //        edgeMessageQueue.clear();
// //
// //        turn(null);
// //        System.gc();
// //
// //
// //        turn(aggregationMessageQueue);
// //
// //        System.gc();
// //
// //        turn(coreMessageQueue);
// //        System.gc();
// //
// //
// //        turn(aggregationMessageQueue);
// //        System.gc();
// //
// //        turn(edgeMessageQueue);
// //        System.gc();
// //        recordCibNum();
// //        removeNode();
// //        System.gc();
// //        System.out.println("============================================");
// //    }

//    void removeSwitch(String pre){
//        List<String> rl = new LinkedList<>();
//        for(String k: deviceMap.keySet()){
//            if(k.startsWith(pre)) {
//                Device d = deviceMap.get(k);
//                d.closeNodes();
//                rl.add(k);
//            }
//        }
//        for(String s:rl){
//            deviceMap.remove(s);
//        }
//    }


//    @Override
//    protected void transfer(OutputStream os, DevicePort src){
//        String dstDevice = topology.get(src).getDeviceName();

//        if(selectAggregation && dstDevice.startsWith("fsw") && !dstDevice.endsWith("-"+ aggregationIndex)) return;
//        if(selectCore && dstDevice.startsWith("ssw") && !dstDevice.equals("ssw-0-0")) return;
// //        if(selectCore && dstDevice.startsWith("ssw") && !dstDevice.startsWith("ssw-0-")) return;
//        threadPool.execute(()-> {
//            if(dstDevice.startsWith("fsw"))
//                aggregationMessageQueue.add(new MessageToken(os, src));
//            else if(dstDevice.startsWith("ssw"))
//                coreMessageQueue.add(new MessageToken(os, src));
//            else if(dstDevice.startsWith("rsw"))
//                edgeMessageQueue.add(new MessageToken(os, src));
//            else
//                System.out.println("no queue:" + dstDevice);
//        });
//    }

//    protected void _transfer(OutputStream os, DevicePort src){
//        ByteArrayInputStream bais = new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray());
//        int size = ((ByteArrayOutputStream) os).size();
//        DevicePort dst = topology.get(src);
// //        if(dst.getDeviceName().equals("ssw-0-0"))
// //            saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));
// //        if(src.getDeviceName().startsWith("ssw") && dst.getDeviceName().equals("fsw-0-0"))
// //            saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));
// //        if(rswSave && src.getDeviceName().startsWith("rsw") && dst.getDeviceName().equals("fsw-0-0"))
// //            saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));
//        Device d = deviceMap.get(dst.getDeviceName());
//        if(d == null){
//            System.out.println("no receive device:" + dst.getDeviceName());
//            return;
//        }
//        CIBMessage cibIn = srl.deserialize(bais, d.bddEngine.getBDD());
//        long t = System.nanoTime();
//        long d_t = System.nanoTime();
//        d.receiveCount(cibIn, dst.getPortName(), t, d_t-t, size);

//    }

//    public static void main(String[] args) {
//        DebugNetwork.saveData = true;
//        int npod = 6;
//        int times = 1;
//        if(args.length > 0){
//            npod = Integer.parseInt(args[0]);
//        }
//        if(args.length > 1){
//            times = Integer.parseInt(args[1]);
//        }
//        Logger.getGlobal().setLevel(Level.SEVERE);
//        Device.THREAD_POOL_SIZE = 1;
//        FBDebugNetwork dn = FBDebugNetwork.buildTopology(npod);
// //        for(int i=0;i<times;i++)
//        dn.onlySource = true;
// //        dn.selectCore = true; dn.coreIndex = 0;
// //        dn.selectAggregation = true; dn.aggregationIndex = 0;
// //        dn.run();
// //        dn.rswSave = true;
//        dn.addEdgeSwitch();
//        dn.addCoreSwitch();
//        dn.addAggregationSwitch();
//        for(int i=0;i<times;i++){
//            dn.sourceIndex = i;
//            dn.addNode(i);
// //            dn.coreIndex = i;
// //            if((i+1) % 24 == 0)
// //            if((i+1) % 48 == 0)    dn.run();
// //            dn.rswSave = false;
//            dn.run();

//        }
//        dn.run();
//        dn.closeBW();
//        dn.close();
// //        dn.checkFree(10, 100);

// //        Recorder.getRecorder().showDeviceGreenStartTime();
//        Recorder.getRecorder().printResult(dn, true);
//        Recorder.getRecorder().showDeviceGreenStartTime();

//    }
// }
