package org.sngroup.testNetwork;

import org.sngroup.verifier.CibMessage;
import org.sngroup.util.DevicePort;
import org.sngroup.verifier.Subscriber;
import org.sngroup.verifier.serialization.Serialization;

/**
 * Network
 */
public abstract class AbstractNetwork {
    /**
     * methods for serialize and deserialize
     */
    public Serialization srl;

    /**
     * 发送计数值
     * @param port 发送计数值的端口
     * @param cibOut 计数结果
     */
    abstract public void sendCount(DevicePort port, CibMessage cibOut);

    abstract public void subscribe(DevicePort port, Subscriber subscriber);
    abstract public void acceptSubscribe(DevicePort port, Subscriber subscriber);

}
