// package org.sngroup.testNetwork;

// import org.sngroup.util.*;
// import org.sngroup.verifier.Announcement;
// import org.sngroup.verifier.Device;
// import org.sngroup.verifier.CibMessage;
// import org.sngroup.verifier.Node;
// import org.sngroup.verifier.Subscriber;
// import org.sngroup.verifier.serialization.Serialization;
// import org.sngroup.testNetwork.AbstractNetwork;
// //import common.serialization.proto.ProtobufSerialization;
// import org.sngroup.verifier.serialization.proto.ProtobufSerialization;
// //import org.sngroup.util.PathNode;

// import java.io.*;
// import java.nio.charset.StandardCharsets;
// import java.util.*;
// import java.util.logging.Logger;

// import static java.lang.Thread.sleep;

// /**
//  * network for debug
//  * all data transfer between Devices is done within an instance object of the class.
//  * cibIO serialize and deserialize by protobuf
//  */
// public class DebugNetwork extends AbstractNetwork {
//     protected static  boolean saveData = false;
//     private static final String saveDataPath = "save/";
//     public static final String VIRTUAL_NODE_NAME = "V";
//     public static final int MAXIMUM_THREAD_POOL_SIZE = 40;
//     // 序列化方法
//     public Serialization srl;

// //    public PathNode rootNode;
// //    public Map<NodePointer, PathNode> pnMap;

//     public Map<String, Device> deviceMap;
//     public Set<String> deviceSet;
//     protected Map<DevicePort, DevicePort> topology;
//     private Map<String, Map<String, Set<DevicePort>>> devicePortSet;
//     protected ThreadPool threadPool;
//     public List<List<NodePointer>> pathList;

//     public String spaceFilename;
//     public String tunnelFilename;
//     public int pathMaxSize;

//     public int spaceLimit = 0;
//     Map<String, BufferedWriter> saveBW;

//     public Thread.UncaughtExceptionHandler ue;

//     public Map<Pair, Long> latencyMap;

// //    final private static Recorder recorder = Recorder.getRecorder();

//     public DebugNetwork(){
//         init();
//     }

// //    public void setNode(GlobalRequirement r){
// //        List<GlobalRequirement.Node> nodes = r.getNodeList();
// //        for (GlobalRequirement.Node node: nodes){
// ////            System.out.println(node);
// //
// //            if(node.router.name.equals(VIRTUAL_NODE_NAME)) continue;
// //            Device d = deviceMap.get(node.router.name);
// //            Collection<NodePointer> prev = new HashSet<>();
// //            Collection<NodePointer> next = new HashSet<>();
// //
// //            for(GlobalRequirement.Node n: node.next){
// //                if(n.router.name.equals(VIRTUAL_NODE_NAME)) continue;
// //                for(DevicePort dp:devicePortSet.get(node.router.name).get(n.router.name))
// //                    next.add(new NodePointer(dp.getPortName(), n.sameNodeIndex));
// //            }
// //            for(GlobalRequirement.Node n: node.prev){
// //                for(DevicePort dp:devicePortSet.get(node.router.name).get(n.router.name))
// //                    prev.add(new NodePointer(dp.getPortName(), n.sameNodeIndex));
// //            }
// //            d.addNode(node.sameNodeIndex, prev, next);
// //        }
// //    }

//     public void addTopology(String d1, String p1, String d2, String p2) {
//         DevicePort dp1 = new DevicePort(d1, p1);
//         DevicePort dp2 = new DevicePort(d2, p2);
//         topology.put(dp1, dp2);
//         topology.put(dp2, dp1);
//         deviceSet.add(d1);
//         deviceSet.add(d2);
//         devicePortSet.putIfAbsent(d1, new HashMap<>());
//         devicePortSet.get(d1).putIfAbsent(d2, new HashSet<>());
//         devicePortSet.get(d1).get(d2).add(dp1);
//         devicePortSet.putIfAbsent(d2, new HashMap<>());
//         devicePortSet.get(d2).putIfAbsent(d1, new HashSet<>());
//         devicePortSet.get(d2).get(d1).add(dp2);
// //        nb.addTopology(d1, p1, d2, p2);
//     }

//     public void addDevice(String name, String ruleFilePath) {
//         Device device = new Device(name, this);
//         device.ue = ue;
//         device.readRulesFile(ruleFilePath);
//         if(tunnelFilename != null){
//             device.readTunnelFile(tunnelFilename);
//         }
//         deviceMap.put(name, device);
//     }

//     public void clearDevice(){
//         deviceMap.clear();
//     }

//     public void addNode(String deviceName, int nodeIdx, Collection<NodePointer> prev, Collection<NodePointer> next, boolean isAccept){
//         if(deviceName.equals(VIRTUAL_NODE_NAME)) return;
//         Device d = deviceMap.get(deviceName);
// //        d.addNode(nodeIdx, prev, next, isAccept);
//     }

//     @Override
//     public void sendCount(DevicePort port, CibMessage cibOut) {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         Device d = deviceMap.get(port.getDeviceName());
//         long s_t = System.nanoTime();
// //        srl.serialize(cibOut, baos, d.bddEngine.getBDD());
//         long t = System.nanoTime();
//         int size = baos.size();
//         transfer(baos, port);
//         NodePointer np = new NodePointer(port.getDeviceName(), cibOut.sourceIndex);
//     }

//     public long getInitTime(){
//         long res = 0;
//         for(Device d: deviceMap.values()){
//             if(d.getInitTime() > res)
//                 res = d.getInitTime();
//         }
// //        System.out.println(res);
//         return res;
//     }
//     @Override
//     public void subscribe(DevicePort port, Subscriber subscriber) {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream();
//         Device d = deviceMap.get(port.getDeviceName());
//         srl.serializeSubscribe(subscriber, baos, d.bddEngine.getBDD());
//         transferSubscribe(baos, port);
//     }

//     @Override
//     public void acceptSubscribe(DevicePort port, Subscriber subscriber){
//         Device device = deviceMap.get(port.getDeviceName());
//         device.acceptSubscribe(port, subscriber);
//     }

//     public void setUe(Thread.UncaughtExceptionHandler handler){
//         this.ue = handler;
//         for(Device d:deviceMap.values()){
//             d.ue = handler;
//         }
//     }

//     public void start(){
//         int traceID = Utility.getRandomString();
//         if(threadPool == null || threadPool.isShutdown())
//             threadPool = ThreadPool.FixedThreadPool(MAXIMUM_THREAD_POOL_SIZE);
//         if(spaceFilename != null)
//             readSpace(spaceFilename);
//         for(Device device:deviceMap.values()){
//             device.initNode();
//         }
//         for(Device device:deviceMap.values()) {
//             device.greenStart = true;
//         }

//         for(Device device:deviceMap.values()) {
//             device.startSubscribe();
//         }
//         awaitFinished();
//         for(Device device:deviceMap.values()) {
// //            device.startCount(traceID);
//         }
// //        for(Device device:deviceMap.values()) {
// //            device.startCount2(traceID);
// //        }
//         awaitFinished();


//     }

// //    public void showResult(){
// //        for(Device d: deviceMap.values()){
// //            if(d.name.equals("21"))
// //                d.showResult();
// //        }
// //    }
//     public Device getDevice(String deviceName){
//         return deviceMap.get(deviceName);
//     }

//     public void closeNodes(){
//         for(Device device: deviceMap.values()){
//             device.closeNodes();
//         }
//     }

//     public void gc(){
//         for(Device device: deviceMap.values()){
//             device.bddEngine.getBDD().bdd.gc();
//         }
//     }


//     public void awaitFinished(){
//         threadPool.awaitAllTaskFinished(100);
//         for (Device device: deviceMap.values()){
//             device.awaitFinished();
//         }

// //        threadPool.awaitAllTaskFinished();
//     }

//     public void close(){
//         awaitFinished();
//         threadPool.shutdownNow();
//         closeNodes();
//         if(saveBW!=null){
//             for(BufferedWriter bw:saveBW.values()){
//                 try {
//                     bw.close();
//                 } catch (IOException e) {
//                     e.printStackTrace();
//                 }
//             }
//         }
//     }

//     /**
//      * 用线程池包装传输数据
//      * @param os 输出流
//      * @param dst 目的端口
//      */
//     protected void transfer(OutputStream os, DevicePort dst){
//         threadPool.execute(()-> {
//             if(ue != null)
//                 Thread.currentThread().setUncaughtExceptionHandler(ue);
//             _transfer(os, dst);
//         });
//     }

//     /**
//      * 实现传输数据
//      * @param os 输出流
//      * @param src 输出端口
//      */
//     protected void _transfer(OutputStream os, DevicePort src){
//         ByteArrayInputStream bais = new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray());
//         int size = ((ByteArrayOutputStream) os).size();
//         DevicePort dst = topology.get(src);


// //        if(saveData) saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));

//         Device d = deviceMap.get(dst.getDeviceName());
//         long time = getLatency(src.getDeviceName(), dst.getDeviceName());
//         long t = System.nanoTime();
// //        CIBMessage cibIn = srl.deserialize(bais, d.bddEngine.getBDD());
// //        long d_t = System.nanoTime();
// //        Event e = d.addReceiveEvent(cibIn.taskID, time, cibIn.prevEvent);
// //        Event e2 = d.addLocalDeviceEvent(cibIn.taskID, d_t-t, e.name);
// //        d.receiveCount(cibIn, dst.getPortName(), e2.name);
//     }
//     /**
//      * 用线程池包装传输数据
//      * @param os 输出流
//      * @param dst 目的端口
//      */
//     protected void transferSubscribe(OutputStream os, DevicePort dst){
//         threadPool.execute(()-> {
//             if(ue != null)
//                 Thread.currentThread().setUncaughtExceptionHandler(ue);
//             _transferSubscribe(os, dst);
//         });
//     }

//     protected void _transferSubscribe(OutputStream os, DevicePort src){
//         ByteArrayInputStream bais = new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray());
//         int size = ((ByteArrayOutputStream) os).size();
//         DevicePort dst = topology.get(src);

//         Device d = deviceMap.get(dst.getDeviceName());

//         Subscriber sub = srl.deserializeSubscribe(bais, d.bddEngine.getBDD());
//         acceptSubscribe(dst, sub);
//     }
//     public void recordCibNum(){
// //        for(Device device: deviceMap.values()){
// //            for(Node2 node:device.nodes.values()){
// //                recorder.addCibNum(node, node.getCibCount());
// ////                recorder.addCibMergeNum(node, node.getCibMergeCount());
// //            }
// //        }
//     }

//     public void recordMemoryUsage(){
//         List<Long> memoryList = new LinkedList<>();
//         for(Device device: deviceMap.values()){
//             memoryList.add(device.getMemoryUsageRecord());
//         }
// //        recorder.addMemoryUsageList("memory", memoryList);
//     }
//     public void readSpace(String filename){
//         if(spaceLimit > 0) {
//             Map<String, Integer> limit = new HashMap<>();
//             for(String device: deviceMap.keySet()){
//                 limit.put(device, spaceLimit);
//             }
//             readSpace(filename, limit);

//         }else{
//             readSpace(filename, new HashMap<>());
//         }
// //        deviceMap.values().forEach(d->System.out.println(d.__count));
//     }
//     public void readSpace(String filename, Map<String, Integer> limit){
//         try {
//             File file = new File(filename);
//             InputStreamReader isr = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);
//             BufferedReader br = new BufferedReader(isr);
//             String line;
//             boolean hasRequirement = false;
//             Set<String> requirements = new HashSet<>();
// //            deviceMap.values().forEach(Device::clearSpace);
//             while ((line = br.readLine()) != null) {
//                 String[] token = line.split(" ");
//                 String name = token[0];
//                 if(name.equals("[requirement]")){
//                     requirements.addAll(Arrays.asList(token).subList(1, token.length));
//                     hasRequirement = true;
//                     continue;
//                 }
//                 if(limit.containsKey(name)){
//                     if(limit.get(name).equals(0)){
//                         continue;
//                     }else{
//                         limit.computeIfPresent(name, (k, v)->v-1);
//                     }
//                 }
//                 long ip = Long.parseLong(token[1]);
//                 int prefix = Integer.parseInt(token[2]);
//                 for(Map.Entry<String, Device> entry: deviceMap.entrySet()){
//                     String dname = entry.getKey();
//                     Device d = entry.getValue();
// //                    if(name.equals(dname))
// //                        d.addSpace(ip, prefix);
//                     if(!hasRequirement || requirements.contains(name))
//                         d.addTotalSpace(name, ip, prefix);
//                 }
//             }
// //            for(Device d: deviceMap.values()){
// //                System.out.println(d.name);
// //                System.out.println("device space: " + d.deviceSpace);
// //                System.out.println("device total space: " + d.totalSpace);
// //            }
//         }catch (Exception e){
//             e.printStackTrace();
//         }

//     }
// //    public void readLatency(String filename){
// //        String FIRST_LINE = "Source,City,Distance,Average(ms)";
// //        try {
// //            File file = new File(filename);
// //            InputStreamReader isr = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);
// //            BufferedReader br = new BufferedReader(isr);
// //            String line;
// //            line = br.readLine();
// //            if(!line.startsWith(FIRST_LINE)) {
// //                Logger.getGlobal().warning("not formal file");
// //                return;
// //            }
// //            latencyMap = new HashMap<>();
// //            while ((line = br.readLine()) != null) {
// //                String[] token = line.split(",");
// //                long latency = (long) Double.parseDouble(token[3])*1000000;
// //                latencyMap.put(new Pair(token[0], token[1]), latency);
// //            }
// //        }catch (Exception e){
// //            e.printStackTrace();
// //        }
// //    }

//     public synchronized void saveBase64(DevicePort recPort, ByteArrayInputStream bais){
//         String base64encodedString = Utility.getBase64FromInputStream(bais);
//         if(saveBW == null) initSaveBW();

//         BufferedWriter bw = saveBW.get(recPort.getDeviceName());
//         if(bw == null) {
//             try {
//                 bw = new BufferedWriter(new FileWriter(saveDataPath + recPort.getDeviceName()));
//                 saveBW.put(recPort.getDeviceName(), bw);
//             } catch (IOException e) {
//                 e.printStackTrace();
//             }
//         }
//         try {
//             long time = System.nanoTime();
//             bw.write(time + " " + recPort.getPortName() + " " + base64encodedString + "\n");
//             bw.flush();
//         } catch (IOException e) {
//             e.printStackTrace();
//         }


//     }

//     public synchronized void initSaveBW(){
//         if(saveData && saveBW == null){
//             saveBW = new Hashtable<>();
//             try {
//                 File _f = new File(saveDataPath);
//                 if(!_f.exists()) _f.mkdirs();
// //                for (String device : deviceMap.keySet()) {
// //                    BufferedWriter bw = new BufferedWriter(new FileWriter(saveDataPath + device));
// //                    saveBW.put(device, bw);
// //                }
//             }catch (Exception e){
//                 e.printStackTrace();
//             }
//         }
//     }

//     public void outputResult(String filename){
//         try {
//             BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
//             for(Device d: deviceMap.values()){
//                 for(Node2 node2: d.nodes.values()){
//                     if(!node2.hasResult) {
//                         System.out.println(node2.getNodeName() + "has not result!!");
//                         return;
//                     }
//                     bw.write(node2.getNodeName() + " ");
//                     for(Announcement a: node2.lastResult.announcements){
//                         bw.write(a.count + " " + d.bddEngine.getSet(a.predicate) + " ");
//                     }
//                     bw.write("\n");
//                 }
//             }
//             bw.close();
//         } catch (IOException e) {
//             e.printStackTrace();
//         }
//     }

//     public void getDeviceInitTime(){
//         for(Device d: deviceMap.values()){
// //            d.addInitTime();
//         }
//     }
//     public long getLatency(String src, String dst){
//         if(latencyMap == null) return 0;
//         Pair p = new Pair(src, dst);
//         if(latencyMap.containsKey(p)) return latencyMap.get(p);
//         String dst2 = dst.substring(0, dst.length() - 2);
//         String src2 = src.substring(0, src.length() - 2);
//         try {
//             p = new Pair(src2, dst2);
//             if (latencyMap.containsKey(p)) return latencyMap.get(p);
//         }catch (Exception ignore){}
//         if(src.equals(dst) || src2.equals(dst2)) return 0;
//         Logger.getGlobal().warning("not such latency:"+p);
//         return 0;
//     }

//     private void init(){
//         deviceMap = new HashMap<>();
//         topology = new HashMap<>();
//         srl = new ProtobufSerialization();
// //        pnMap = new HashMap<>();
//         pathList = new LinkedList<>();
//         deviceSet = new HashSet<>();
//         ue = null;
//         devicePortSet = new HashMap<>();
//         saveBW = null;
//         spaceFilename = null;
//     }

//     public void showNodeNums() {
//         for(Device device: deviceMap.values()){
//             System.out.println(device.name+" node num:" + device.nodes.size() );
//         }
//     }

//     static class Pair{
//         public String source;
//         public String target;

//         public Pair(String source, String target){
//             this.source = source;
//             this.target = target;
//         }

//         @Override
//         public boolean equals(Object o) {
//             if (this == o) return true;
//             if (!(o instanceof Pair)) return false;
//             Pair pair = (Pair) o;
//             return source.equals(pair.source) && target.equals(pair.target);
//         }

//         @Override
//         public int hashCode() {
//             return Objects.hash(source, target);
//         }

//         @Override
//         public String toString() {
//             return "Pair{" +
//                     "source='" + source + '\'' +
//                     ", target='" + target + '\'' +
//                     '}';
//         }
//     }

// }
