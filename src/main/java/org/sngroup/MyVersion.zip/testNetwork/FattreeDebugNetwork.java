// package org.sngroup.verifier.network;

// import org.sngroup.util.DevicePort;
// import org.sngroup.util.Recorder;
// import org.sngroup.verifier.Device;
// import org.sngroup.util.NodePointer;
// import org.sngroup.util.Rule;

// import java.io.*;

// import java.util.LinkedList;
// import java.util.List;
// import java.util.Queue;
// import java.util.concurrent.LinkedBlockingQueue;
// import java.util.logging.Level;
// import java.util.logging.Logger;

// public class FattreeDebugNetwork extends DebugNetwork{
//    Queue<MessageToken> edgeMessageQueue;
//    Queue<MessageToken> coreMessageQueue;
//    Queue<MessageToken> aggregationMessageQueue;
//    int npod;
//    int sourceIndex;
//    int aggregationIndex;
//    int coreIndex;
//    int edgeIndex;

//    boolean onlySource;
//    boolean selectAggregation;
//    boolean selectCore;
//    boolean selectEdge;
//    boolean rswSave;

//    public FattreeDebugNetwork(int npod){
//        super();
//        aggregationMessageQueue = new LinkedBlockingQueue<>();
//        coreMessageQueue = new LinkedBlockingQueue<>();
//        edgeMessageQueue = new LinkedBlockingQueue<>();
//        this.npod = npod;
//        onlySource = true;
//        selectAggregation = false;
//        selectCore = false;
//        selectEdge = false;
//        rswSave = false;
//    }

//    private static FattreeDebugNetwork buildTopology(int k) {
//        FattreeDebugNetwork n = new FattreeDebugNetwork(k);
//        //// create links
//        for (int iPod = 0; iPod < k; iPod++) {
//            for (int iFsw = 0; iFsw < k / 2; iFsw++) {
//                String fsw = "fsw-" + iPod + "-" + iFsw;
//                // down links
//                for (int iRsw = 0; iRsw < k / 2; iRsw++) {
//                    String rsw = "rsw-" + iPod + "-" + iRsw;
//                    n.addTopology(fsw, fsw + ">" + rsw, rsw, rsw + ">" + fsw);
//                }
//                // up links
//                for (int iSsw = iFsw * k / 2; iSsw < iFsw * k / 2 + k / 2; iSsw++) {
//                    String ssw = "ssw-" + iSsw;
//                    n.addTopology(fsw, fsw + ">" + ssw, ssw, ssw + ">" + fsw);
//                }
//            }
//        }
//        //// \create links
//        return n;
//    }

// //    public static FattreeDebugNetwork getNetwork(int npod) {
// //        FattreeDebugNetwork n = buildTopology(npod);
// //        //// create rules
// //        // first 8 bits is pod id, next 8 bit is index of rsw in pod
// //        n.addEdgeSwitch(npod);
// //        n.addAggregationSwitch(npod);
// //        n.addCoreSwitch(npod);
// //        for(Device d: n.deviceMap.values()){
// //            d.runNode();
// //        }
// //        return n;
// //    }

//    public void addEdgeSwitch(){
//        addEdgeSwitch(true);
//    }

//    public void addEdgeSwitch(boolean addInitTime){
//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iRsw = 0; iRsw < npod / 2; iRsw++) {
//                if(selectEdge && edgeIndex!=iRsw) continue;
//                String rsw = "rsw-" + iPod + "-" + iRsw;
//                Device device = new Device(rsw, this);
//                deviceMap.put(rsw, device);
//                List<Rule> rules = new LinkedList<>();
//                for (int jPod = 0; jPod < npod; jPod++) {
//                    for (int jRsw = 0; jRsw < npod / 2; jRsw++) {
//                        String dstrsw = "rsw-" + jPod + "-" + jRsw;
//                        long dstip = ((long) jPod << 24) + ((long) (jRsw + 1) << 16);
//                        if (dstrsw.equals(rsw)) {
//                            device.addSpace(dstip, 16);
//                            rules.add(new Rule(dstip, 16, rsw + ">h-" + jPod + "-" + jRsw));
//                        } else {
//                            String dstfsw = "fsw-" + iPod + "-" + (npod / 2 * jPod + jRsw) % (npod / 2);
//                            rules.add(new Rule(dstip, 16, rsw + ">" + dstfsw));
//                        }
//                    }
//                }
//                device.readRules(rules);
//            }
//        }
//        addEdgeNode();
//    }

//    public void addEdgeNode(Device device, int pod, int rsw){
//        List<NodePointer> next = new LinkedList<>();
//        List<NodePointer> prev = new LinkedList<>();
//        int i = pod * (npod / 2) + rsw;
//        for (int jRsw = 0; jRsw < npod/2; jRsw++) {
//            String dstfsw = "fsw-" + pod + "-" + jRsw;
//            next.add(new NodePointer(device.name + ">" + dstfsw, rsw));
//            for (int index = 0; index <= npod/2; index++) {
//                if(index == rsw) continue;
//                prev.add(new NodePointer(device.name + ">" + dstfsw, index));
//            }
//        }

//        device.addNode(0, new LinkedList<>(), next);
//        device.addNode(1, prev, new LinkedList<>());
//    }

//    public void addEdgeNode(){
//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iRsw = 0; iRsw < npod / 2; iRsw++) {
//                String rsw = "rsw-" + iPod + "-" + iRsw;
//                Device device = deviceMap.get(rsw);
//                addEdgeNode(device, iPod, iRsw);
//            }
//        }
//    }

//    public void addAggregationSwitch(){
//        for (int iPod = 0; iPod < npod; iPod++){
//            for (int iFsw = 0; iFsw < npod/2; iFsw++) {
//                String fsw = "fsw-" + iPod + "-" + iFsw;
//                Device device = new Device(fsw, this);
//                deviceMap.put(fsw, device);
//                List<Rule> rules = new LinkedList<>();
//                for (int jPod = 0; jPod < npod; jPod++) {
//                    for (int jRsw = 0; jRsw < npod/2; jRsw++) {
//                        String dstrsw = "rsw-" + jPod + "-" + jRsw;
//                        long dstip = ((long) jPod << 24) + ((long) (jRsw + 1) << 16);
//                        if (jPod == iPod) { // intra pod
//                            rules.add(new Rule(dstip, 16, fsw + ">" + dstrsw));
//                        } else {
//                            String dstssw = "ssw-" + (iFsw * (npod/2) + ((npod/2) * jPod + jRsw) % (npod/2));
//                            rules.add(new Rule(dstip, 16, fsw + ">" + dstssw));
//                        }
//                    }
//                }
//                device.readRules(rules);
//            }
//        }
//        addAggregationNode();
//    }

//    public void addAggregationNode(Device device, int iPod, int fsw){

//        for(int index=0; index<npod; index++){
//            List<NodePointer> next = new LinkedList<>();
//            List<NodePointer> prev = new LinkedList<>();
//            prev.add(new NodePointer(device.name + ">" + "rsw-" + iPod + "-" + index, 0));
//            for (int iSsw = fsw * npod / 2; iSsw < fsw * npod / 2 + npod / 2; iSsw++) {
//                next.add(new NodePointer(device.name + ">" + "ssw-" + iSsw, fsw));
//            }
//            for (int kRsw = 0; kRsw < npod / 2; kRsw++) {
//                if (kRsw == index) continue;
//                next.add(new NodePointer(device.name + ">" + "rsw-" + iPod + "-" + kRsw, 1));
//            }
//            device.addNode(index, prev, next);
//        }

//        List<NodePointer> next = new LinkedList<>();
//        List<NodePointer> prev = new LinkedList<>();
//        for (int kRsw = 0; kRsw < npod / 2; kRsw++) {
//            next.add(new NodePointer(device.name + ">" + "rsw-" + iPod + "-" + kRsw, 1));
//        }
//        for (int iSsw = fsw * npod / 2; iSsw < fsw * npod / 2 + npod / 2; iSsw++) {
//            for(int index=0;index<npod;index++) {
//                if (index == fsw) continue;
//                prev.add(new NodePointer(device.name + ">" + "ssw-" + iSsw, index));
//            }
//        }
//        device.addNode(npod, prev, next);
//    }

//    public void addAggregationNode(){
//        for (int iPod = 0; iPod < npod; iPod++) {
//            for (int iFsw = 0; iFsw < npod / 2; iFsw++) {
//                String fsw = "fsw-" + iPod + "-" + iFsw;
//                Device device = deviceMap.get(fsw);
//                if(device != null)
//                    addAggregationNode(device, iPod, iFsw);
//            }
//        }
//    }

//    public void addCoreSwitch(){
//        for (int iSsw = 0; iSsw < npod*npod/4; iSsw++) {
//            if(selectCore && iSsw!=coreIndex) continue;
//            String ssw = "ssw-" + iSsw;
//            Device device = new Device(ssw, this);
//            deviceMap.put(ssw, device);
//            List<Rule> rules = new LinkedList<>();
//            for (int k = 0; k < npod; k++) {
//                for (int l = 0; l < npod/2; l++) {
//                    long dstip = ((long) k << 24) + ((long) (l + 1) << 16);
//                    String dstfsw = "fsw-" + k + "-" + (iSsw / (npod/2));
//                    rules.add(new Rule(dstip, 16, ssw + ">" + dstfsw));
//                }
//            }
//            device.readRules(rules);
//        }
//        addCoreNode();
//    }


//    public void addCoreNode(Device device, int iSsw) {
//        int index = (iSsw / (npod / 2));
//        for(int iPod=0; iPod<npod; iPod++){
//            List<NodePointer> next = new LinkedList<>();
//            List<NodePointer> prev = new LinkedList<>();
//            prev.add(new NodePointer(device.name + ">" + "fsw-" + iPod + "-" + index, index));
//            for(int jPod=0; jPod<=npod; jPod++){
//                if(jPod==iPod) continue;
//                next.add(new NodePointer(device.name + ">" + "fsw-" + iPod + "-" + index, index));
//            }
//            device.addNode(index, prev, next);
//        }
//    }

//    public void addCoreNode(){
//        for (int iSsw = 0; iSsw < npod*npod/4; iSsw++) {
//                String ssw = "ssw-" + iSsw;
//                Device device = deviceMap.get(ssw);
//                if(device != null)
//                    addCoreNode(device, iSsw);
//        }
//    }

//    public void removeNode(){
//        for(Device device: deviceMap.values()){
//            device.nodes.clear();
//            device.dstNodes.clear();
//        }
//        gc();
//    }

// //    @Override
// //    protected void transfer(OutputStream os, DevicePort src){
// //        String dstDevice = topology.get(src).getDeviceName();
// //
// //        if(selectAggregation && dstDevice.startsWith("fsw") && !dstDevice.endsWith("-"+ aggregationIndex)) return;
// //        if(selectCore && dstDevice.startsWith("ssw") && !dstDevice.endsWith("-"+ coreIndex)) return;
// //        threadPool.execute(()-> {
// //            if(dstDevice.startsWith("fsw"))
// //                aggregationMessageQueue.add(new MessageToken(os, src));
// //            else if(dstDevice.startsWith("ssw"))
// //                coreMessageQueue.add(new MessageToken(os, src));
// //            else if(dstDevice.startsWith("rsw"))
// //                edgeMessageQueue.add(new MessageToken(os, src));
// //            else
// //                System.out.println("no queue2:"+dstDevice);
// //        });
// //    }
// //
// //    void turn(Queue<MessageToken> messageQueue){
// //        if(messageQueue == null || messageQueue.isEmpty()){
// //            start();
// //        }else{
// //            while(!messageQueue.isEmpty()){
// //                MessageToken mt = messageQueue.poll();
// //                threadPool.execute(()-> _transfer(mt.os, mt.dst));
// //            }
// //        }
// //        if(!checkFree(100, 1000)){
// //            System.err.println("timeout!");
// //        }
// //
// //        System.out.println(sourceIndex+ " edge message size:" + edgeMessageQueue.size());
// //        System.out.println(sourceIndex+ " aggr message size:" + aggregationMessageQueue.size());
// //        System.out.println(sourceIndex+ " core message size:" + coreMessageQueue.size());
// //        System.out.println(" -----------------------------------");
// //    }
// //
// //    protected void _transfer(OutputStream os, DevicePort src){
// //        ByteArrayInputStream bais = new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray());
// //        int size = ((ByteArrayOutputStream) os).size();
// //        DevicePort dst = topology.get(src);
// //        if(dst.getDeviceName().equals("ssw-0-0"))
// //            saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));
// ////        if(src.getDeviceName().startsWith("ssw") && dst.getDeviceName().equals("fsw-0-0"))
// ////            saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));
// ////        if(rswSave && src.getDeviceName().startsWith("rsw") && dst.getDeviceName().equals("fsw-0-0"))
// ////            saveBase64(dst, new ByteArrayInputStream(((ByteArrayOutputStream) os).toByteArray()));
// //        Device d = deviceMap.get(dst.getDeviceName());
// //        if(d == null){
// //            System.out.println("no receive device:" + dst.getDeviceName());
// //            return;
// //        }
// //        CIBMessage cibIn = srl.deserialize(bais, d.bddEngine.getBDD());
// //        long t = System.nanoTime();
// //        long d_t = System.nanoTime();
// //        d.receiveCount(cibIn, dst.getPortName(), t, d_t-t, size);
// //
// //    }
// //        public void run(FattreeDebugNetwork dn){
// //            dn.start();
// //            dn.showNodeNums();
// //            dn.recordMemoryUsage();
// //
// //            for(int i=0;i<times-1;i++) {
// //                System.out.println(i);
// //                dn.getDeviceInitTime();
// //                nl.rebuildGS(dn);
// //            }
// //            dn.close();
// //            Recorder.getRecorder().printResult(dn);
// //            Recorder.getRecorder().showDeviceGreenStartTime();
// //            Recorder.getRecorder().printMemoryUsage();
// //        }
// //    public void run(){
// //        aggregationMessageQueue.clear();
// //        coreMessageQueue.clear();
// //        edgeMessageQueue.clear();
// //        addEdgeSwitch();
// //        turn(null);
// //        deviceMap.values().forEach(Device::closeNodes);
// //        deviceMap.clear();
// //        System.gc();
// //        addAggregationSwitch();
// //        turn(aggregationMessageQueue);
// //
// //        addCoreSwitch();
// //        turn(coreMessageQueue);
// //        deviceMap.values().forEach(d->{if(d.name.startsWith("ssw")) d.closeNodes();});
// //        System.gc();
// //
// //        turn(aggregationMessageQueue);
// //        deviceMap.values().forEach(Device::closeNodes);
// //        deviceMap.clear();
// //        System.gc();
// //
// //        addEdgeSwitch(false);
// //        turn(edgeMessageQueue);
// //        deviceMap.values().forEach(Device::closeNodes);
// //        deviceMap.clear();
// //        close();
// //        System.gc();
// //        System.out.println("============================================");
// //    }


//    public static void main(String[] args) {
//        int npod = 4;
//        int times = 2;
//        if(args.length > 0){
//            npod = Integer.parseInt(args[0]);
//        }
//        if(args.length > 1){
//            times = Integer.parseInt(args[1]);
//        }
//        Logger.getGlobal().setLevel(Level.SEVERE);
//        Device.THREAD_POOL_SIZE = 1;
//        FattreeDebugNetwork dn = FattreeDebugNetwork.buildTopology(npod);
//        dn.addCoreSwitch();
//        dn.addAggregationSwitch();
//        dn.addEdgeSwitch();
//        dn.start();
//        dn.showNodeNums();
//        dn.recordMemoryUsage();
//        dn.close();
// //        for(int i=0;i<times;i++)
// //        dn.onlySource = false;
// //        dn.selectCore = true; dn.coreIndex = 0;
// //        dn.selectAggregation = true; dn.aggregationIndex = 0;
// //        for(int i=0;i<npod/2;i++){
// //            dn.coreIndex = i;
// //            dn.run();
// //            dn.rswSave = false;
// //        }
// //        dn.closeBW();
// //        dn.checkFree(10, 100);
// //        dn.start();
// //        Recorder.getRecorder().showDeviceGreenStartTime();
//        Recorder.getRecorder().printResult(dn, true);
//        Recorder.getRecorder().showDeviceGreenStartTime();

//    }
//    public void close(){
//        awaitFinished();
//        threadPool.shutdownNow();
//        closeNodes();
//    }

//    public void closeBW(){
//        if(saveBW!=null){
//            for(BufferedWriter bw:saveBW.values()){
//                try {
//                    bw.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//    }
//    class MessageToken{
//        OutputStream os;
//        DevicePort dst;
//        MessageToken(OutputStream os, DevicePort dst){
//            this.os = os;
//            this.dst = dst;
//        }
//    }
// }
